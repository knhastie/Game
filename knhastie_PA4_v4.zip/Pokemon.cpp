#include "Point2D.h"
#include "Vector2D.h"
#include "GameObject.h"
#include "Building.h"
#include "PokemonCenter.h"
#include "PokemonGym.h"
#include "BattleArena.h"
#include "Rival.h"
#include "Pokemon.h"
#include <iostream>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;


Pokemon::Pokemon() :GameObject('P')
{
	speed = 5;
	is_in_gym = false;
	is_in_center = false;
	is_in_arena = false;
	stamina = 20;
	experience_points = 0;
	health = 20;
	store_health = health;
	physical_damage = 5;
	magical_damage = 4;
	defense = 15;
	pokemon_dollars = 0;
	training_units_to_buy = 0;
	stamina_points_to_buy = 0;
	name = "Default Pokemon";
	current_center = NULL;
	current_gym = NULL;
	current_arena = NULL;
	target = NULL;
	cout << "Pokemon default constructed" << endl;
}
//default Pokemon constructor.  Sets speed to 5.

Pokemon::Pokemon(char in_code) :GameObject(in_code)
{
	state = STOPPED;
	speed = 5;
	is_in_gym = false;
	is_in_center = false;
	is_in_arena = false;
	stamina = 20;
	experience_points = 0;
	health = 20;
	store_health = health;
	physical_damage = 5;
	magical_damage = 4;
	defense = 15;
	pokemon_dollars = 0;
	training_units_to_buy = 0;
	stamina_points_to_buy = 0;
	name = "Default Pokemon";
	current_center = NULL;
	current_gym = NULL;
	current_arena = NULL;
	target = NULL;
	cout << "Pokemon default constructed" << endl;
}
//Pokemon constructor given only display_code.  Sets speed to 5 and state to stopped

Pokemon::Pokemon(string in_name, double in_speed, double hp, double phys_dmg, double magic_dmg, double def, int in_id, char in_code, Point2D in_loc) :GameObject(in_loc, in_id, in_code)
{
	speed = in_speed;
	is_in_gym = false;
	is_in_center = false;
	is_in_arena = false;
	stamina = 20;
	experience_points = 0;
	health = hp;
	store_health = health;
	physical_damage = phys_dmg;
	magical_damage = magic_dmg;
	defense = def;
	pokemon_dollars = 0;
	training_units_to_buy = 0;
	stamina_points_to_buy = 0;
	name = in_name;
	current_center = NULL;
	current_gym = NULL;
	current_arena = NULL;
	target = NULL;
	cout << "Pokemon constructed" << endl;
}
//Pokemon constructor given GameObject variables, name and speed.

void Pokemon::StartMoving(Point2D dest)
{
	double xleft = fabs(dest.x - location.x);
	double yleft = fabs(dest.y - location.y);
	delta = ((dest - location) * (speed / GetDistanceBetween(dest, location)));
	//used formulas from SetupLocation and UpdateLocation above to determine if Pokemon is already within one step of destination in first else if
	if (location.x == dest.x && location.y == dest.y)
		cout << display_code << id_num << ": I'm already there. See?" << endl;
	else if (xleft <= fabs(delta.x) && yleft <= fabs(delta.y))
	{
		location = dest;
		cout << display_code << id_num << ": I'm already there. See?" << endl;
	}
	//included the above else if because if Pokemon is within one step of destination, they are, by game rules, already there.
	else if (state == EXHAUSTED)
		cout << display_code << id_num << ": I am exhausted. I may move but you cannot see me." << endl;
	else
	{
		cout << display_code << id_num << ": On my way" << endl;
		if (is_in_center)
			current_center->RemoveOnePokemon();
		if (is_in_gym)
			current_gym->RemoveOnePokemon();
		if (is_in_arena)
			current_arena->RemoveOnePokemon();
		//removes one Pokemon from building Pokemon is leaving
		state = MOVING;
		SetupDestination(dest);
	}
}
//Starts Pokemon moving towards given destination.  Other options if Pokemon is already there (includes already within one step) or exhausted.

void Pokemon::StartMovingToCenter(PokemonCenter* center)
{
	Point2D centerloc = center->GetLocation();
	double xleft = fabs(centerloc.x - location.x);
	double yleft = fabs(centerloc.y - location.y);
	delta = ((centerloc - location) * (speed / GetDistanceBetween(centerloc, location)));
	//used formulas from SetupLocation and UpdateLocation above to determine if Pokemon is already within one step of destination in first else if
	if (location.x == centerloc.x && location.y == centerloc.y)
		cout << display_code << id_num << ": I am already at the Pokemon Center!" << endl;
	else if (xleft <= fabs(delta.x) && yleft <= fabs(delta.y))
	{
		location = centerloc;
		cout << display_code << id_num << ": I'm already there. See?" << endl;
	}
	//included the above else if because if Pokemon is within one step of destination, they are, by game rules, already there.
	else if (state == EXHAUSTED)
		cout << display_code << id_num << ": I am exhausted so I can't move to recover stamina..." << endl;
	else
	{
		cout << display_code << id_num << ": On my way to center " << center->GetId() << endl;
		state = MOVING_TO_CENTER;
		if (is_in_center)
			current_center->RemoveOnePokemon();
		if (is_in_gym)
			current_gym->RemoveOnePokemon();
		if (is_in_arena)
			current_arena->RemoveOnePokemon();
		//removes one Pokemon from building Pokemon is leaving
		SetupDestination(centerloc);
	}
	current_center = center;
	//This should happen whether Pokemon has to (or can) move to reach center or not, but must happen after AddOnePokemon and RemoveOnePokemon functions are potentially called!
	//Because StartMoving functions are void, it can be placed after if statements and will still be carried out--no return statements within if statements
}
//Starts Pokemon moving towards given center's location.  Other options if Pokemon is already there (includes already within one step) or exhausted.

void Pokemon::StartMovingToGym(PokemonGym* gym)
{
	Point2D gymloc = gym->GetLocation();
	double xleft = fabs(gymloc.x - location.x);
	double yleft = fabs(gymloc.y - location.y);
	delta = ((gymloc - location) * (speed / GetDistanceBetween(gymloc, location)));
	//used formulas from SetupLocation and UpdateLocation above to determine if Pokemon is already within one step of destination in first else if
	if (location.x == gymloc.x && location.y == gymloc.y)
		cout << display_code << id_num << ": I am already at the Pokemon Gym!" << endl;
	else if (xleft <= fabs(delta.x) && yleft <= fabs(delta.y))
	{
		location = gymloc;
		cout << display_code << id_num << ": I'm already there. See?" << endl;
	}
	//included the above else if because if Pokemon is within one step of destination, they are, by game rules, already there.
	else if (state == EXHAUSTED)
		cout << display_code << id_num << ": I am exhausted so I shouldn't be going to the gym..." << endl;
	else
	{
		cout << display_code << id_num << ": On my way to the gym " << gym->GetId() << endl;
		state = MOVING_TO_GYM;
		if (is_in_center)
			current_center->RemoveOnePokemon();
		if (is_in_gym)
			current_gym->RemoveOnePokemon();
		if (is_in_arena)
			current_arena->RemoveOnePokemon();
		//removes one Pokemon from building Pokemon is leaving
		SetupDestination(gymloc);
	}
	current_gym = gym;
	//This should happen whether Pokemon has to (or can) move to reach center or not, but must happen after AddOnePokemon and RemoveOnePokemon functions are potentially called!
	//Because StartMoving functions are void, it can be placed after if statements and will still be carried out--no return statements within if statements
}
//Starts Pokemon moving towards given gym's location.  Other options if Pokemon is already there (includes already within one step or exhausted.


void Pokemon::StartMovingToArena(BattleArena* arena)
{
	Point2D arenaloc = arena->GetLocation();
	double xleft = fabs(arenaloc.x - location.x);
	double yleft = fabs(arenaloc .y - location.y);
	delta = ((arenaloc - location) * (speed / GetDistanceBetween(arenaloc, location)));
	//used formulas from SetupLocation and UpdateLocation above to determine if Pokemon is already within one step of destination in first else if
	if (location.x == arenaloc.x && location.y == arenaloc.y)
		cout << display_code << id_num << ": I am already at the Battle Arena!" << endl;
	else if (xleft <= fabs(delta.x) && yleft <= fabs(delta.y))
	{
		location = arenaloc;
		cout << display_code << id_num << ": I'm already there. See?" << endl;
	}
	//included the above else if because if Pokemon is within one step of destination, they are, by game rules, already there.
	else if (state == EXHAUSTED)
		cout << display_code << id_num << ": I am exhausted so I shouldn't be going to the arena..." << endl;
	else
	{
		cout << display_code << id_num << ": On my way to the arena " << arena->GetId() << endl;
		state = MOVING_TO_ARENA;
		if (is_in_center)
			current_center->RemoveOnePokemon();
		if (is_in_gym)
			current_gym->RemoveOnePokemon();
		if (is_in_arena)
			current_arena->RemoveOnePokemon();
		//removes one Pokemon from building Pokemon is leaving
		SetupDestination(arenaloc);
	}
	current_arena = arena;
	//This should happen whether Pokemon has to (or can) move to reach center or not, but must happen after AddOnePokemon and RemoveOnePokemon functions are potentially called!
	//Because StartMoving functions are void, it can be placed after if statements and will still be carried out--no return statements within if statements
}

void Pokemon::StartTraining(unsigned int num_training_units)
{
	if (state == EXHAUSTED)
		cout << display_code << id_num << ": I am exhausted so no more training for me!" << endl;
	else if (!is_in_gym)
		cout << display_code << id_num << ": I can only train in a Pokemon Gym!" << endl;
	else if (!current_gym->IsAbleToTrain(num_training_units, pokemon_dollars, stamina))
		cout << display_code << id_num << ": Not enough money/stamina to train" << endl;
	else if (current_gym->IsBeaten())
		cout << display_code << id_num << ": Cannot train!  This Pokemon Gym is already beaten!" << endl;
	else
	{
		cout << display_code << id_num << ": Started to train at Pokemon Gym " << current_gym->GetId() << " with " << current_gym->GetNumTrainingUnitsRemaining() << " training units" << endl;
		state = TRAINING_IN_GYM;
		if (num_training_units < current_gym->GetNumTrainingUnitsRemaining())
			training_units_to_buy = num_training_units;
		else
			training_units_to_buy = current_gym->GetNumTrainingUnitsRemaining();
	}
}
//Starts Pokemon training in current gym if Pokemon is at an unbeaten gym, not exhausted, and has enough money and stamina to train
//Sets Pokemon's training_units_to_buy to num_training_units or to remaining training units in current gym (whichever is smaller)

void Pokemon::StartRecoveringStamina(unsigned int num_stamina_points)
{
	if (!is_in_center)
		cout << display_code << id_num << ": I can only recover stamina at a Pokemon center!" << endl;
	else if (!current_center->HasStaminaPoints())
		cout << display_code << id_num << ": Cannot recover! No stamina points remaining in this Pokemon Center" << endl;
	else if (!current_center->CanAffordStaminaPoints(num_stamina_points, pokemon_dollars))
		cout << display_code << id_num << ": Not enough money to recover stamina" << endl;
	else
	{
		cout << display_code << id_num << ": Started recovering " << num_stamina_points << " at Pokemon Center " << current_center->GetId() << endl;
		state = RECOVERING_STAMINA;
		if (num_stamina_points < current_center->GetNumStaminaPointsRemaining())
			stamina_points_to_buy = num_stamina_points;
		else
			stamina_points_to_buy = current_center->GetNumStaminaPointsRemaining();
	}
}
//Starts Pokemon recovering stamina in current center if Pokemon is at a center with stamina points and has enough money to recover stamina
//Sets Pokemon's stamina_points_to_buy to num_stamina_points or to remaining stamina points in current center (whichever is smaller)



void Pokemon::Stop()
{
	state = STOPPED;
	cout << display_code << id_num << ": Stopping..." << endl;
}
//Stops Pokemon

bool Pokemon::IsExhausted()
{
	if (stamina == 0)
		return true;
	else
		return false;
}
//Returns true if stamina=0

bool Pokemon::ShouldBeVisible()
{
	if (state == EXHAUSTED)
		return false;
	else
		return true;
}
//Returns true if Pokemon is not exhausted

void Pokemon::ShowStatus()
{
	cout << name << " status: ";
	GameObject::ShowStatus();
	switch (GetState())
	{
	case STOPPED: cout << " stopped" << endl;
		break;
	case MOVING: cout << " moving at a speed of " << speed << " to destination " << destination << " at each step of " << delta << endl;
		break;
	case MOVING_TO_CENTER: cout << " heading to Pokemon Center " << current_center->GetId() << " at a speed of " << speed << " at each step of " << delta << endl;
		break;
	case MOVING_TO_GYM: cout << " heading to Pokemon Gym " << current_gym->GetId() << " at a speed of " << speed << " at each step of " << delta << endl;
		break;
	case IN_CENTER: cout << " inside Pokemon Center " << current_center->GetId() << endl;
		break;
	case IN_GYM: cout << " inside Pokemon Gym " << current_gym->GetId() << endl;
		break;
	case TRAINING_IN_GYM: cout << " training in Pokemon Gym " << current_gym->GetId() << endl;
		break;
	case RECOVERING_STAMINA: cout << " recovering stamina in Pokemon Center " << current_center->GetId() << endl;
		break;
	case IN_ARENA: cout << " inside Arena " << current_arena->GetId() << endl;
		break;
	case MOVING_TO_ARENA: cout << " heading to Battle Arena" << current_arena->GetId() << " at a speed of " << speed << " at each step of " << delta << endl;
		break;
	case BATTLE: cout << " battling Rival " << target->get_name() << " in Battle Arena " << current_arena->GetId() << endl;
		break;
	case FAINTED: cout << " fainted" << endl;
		break;
	}
	cout << "Stamina: " << stamina << endl;
	cout << "Pokemon Dollars: " << pokemon_dollars << endl;
	cout << "Experience Points: " << experience_points << endl;
	cout << "Health: " << health << endl;
	cout << "Physical Damage: " << physical_damage << endl;
	cout << "Magical Damage: " << magical_damage << endl;
	cout << "Defense: " << defense << endl;
}
//Shows GameObject and state-specific Pokemon status

bool Pokemon::Update()
{
	bool uploc;
	unsigned int stamnew;
	unsigned int expnew;
	switch (GetState())
	{
	case STOPPED: return false;
	case MOVING: uploc = UpdateLocation();
		if (uploc == 1)
		{
			state = STOPPED;
			return true;
		}
		else
			return false;
	case EXHAUSTED: cout << name << " is out of stamina and can't move" << endl;
		return false;
	case MOVING_TO_CENTER: uploc = UpdateLocation();
		if (uploc == 1)
		{
			is_in_center = true;
			state = IN_CENTER;
			current_center->AddOnePokemon();
			//adds one Pokemon to current_center only when Pokemon reaches center
			return true;
		}
		else
			return false;
	case MOVING_TO_GYM: uploc = UpdateLocation();
		if (uploc == 1)
		{
			is_in_gym = true;
			state = IN_GYM;
			current_gym->AddOnePokemon();
			//adds one Pokemon to current_gym only when Pokemon reaches gym
			return true;
		}
		else
			return false;
	case IN_CENTER: return false;
	case IN_GYM: return false;
	case TRAINING_IN_GYM: stamina = stamina - current_gym->GetStaminaCost(training_units_to_buy);
		pokemon_dollars = pokemon_dollars - current_gym->GetDollarCost(training_units_to_buy);
		expnew = current_gym->TrainPokemon(training_units_to_buy);
		experience_points = experience_points + expnew;
		cout << "**" << name << " completed " << training_units_to_buy << " training unit(s)!**" << endl;
		cout << "**" << name << " gained " << expnew << " experience point(s)!**" << endl;
		state = IN_GYM;
		return true;
	case RECOVERING_STAMINA: stamnew = current_center->DistributeStamina(stamina_points_to_buy);
		stamina = stamina + stamnew;
		pokemon_dollars = pokemon_dollars - current_center->GetDollarCost(stamina_points_to_buy);
		cout << "**" << name << " recovered " << stamnew << " stamina points!**" << endl;
		state = IN_CENTER;
		return true;
	case MOVING_TO_ARENA: uploc = UpdateLocation();
		if (uploc == 1)
		{
			is_in_arena = true;
			state = IN_ARENA;
			current_arena->AddOnePokemon();
			//adds one Pokemon to current_arena only when Pokemon reaches arena
			return true;
		}
		else
			return false;
	case IN_ARENA: return false;
	case BATTLE: //decrease stamina and pokemon dollars according to arena cost
		if (StartBattle())
		{
			health = store_health;
			state = IN_ARENA;
		}
		else
			state = FAINTED;
		target->IsAlive();
		return true;
	case FAINTED: return false;
	}
}
//Updates Pokemon states

bool Pokemon::UpdateLocation()
{
	double xleft = fabs(destination.x - location.x);
	double yleft = fabs(destination.y - location.y);
	if (xleft <= fabs(delta.x) && yleft <= fabs(delta.y))
	{
		location = destination;
		cout << display_code << id_num << ": I'm there!" << endl;
		return true;
	}
	else
	{
		location = location + delta;
		cout << display_code << id_num << ": step..." << endl;
		stamina = stamina - 1;
		pokemon_dollars = pokemon_dollars + GetRandomAmountOfPokemonDollars();
		return false;
	}
}
//Updates object's location while it is moving
//also updates stamina and pokemon_dollars per speed-sized step taken

void Pokemon::SetupDestination(Point2D dest)
{
	destination = dest;
	delta = ((destination - location) * (speed / GetDistanceBetween(destination, location)));
}
//Sets up object to start moving towards destination (sets destination and delta)

static double GetRandomAmountOfPokemonDollars()
{
	//do this only once at beginning of program!  so NOT in this function!
	//srand(time(NULL));
	return (rand() % 21) / 10;
	// %21 puts output between 0 and 20
	// /10 puts output betwen 0.0 and 2.0
}
//returns random value between 0.0 and 2.0 inclusive

bool Pokemon::IsAlive()
{
	if (state == FAINTED)
		return false;
	else
		return true;
}

void Pokemon::TakeHit()
{
	int num = (rand()) % 2;
	if (num == 1)
	{
		double damage = (100 - defense) / 100 * physical_damage;
		health = health - damage;
		cout << name << " : Physical damage hurts, Master!" << endl;
		cout << "Damage: " << damage << endl << "Health: " << health << endl << "*******" << endl;
	}
	else
	{
		double damage = (100 - defense) / 100 * magical_damage;
		health = health - damage;
		cout << name << " : It is magic, Master!" << endl;
		cout << "Damage: " << damage << endl << "Health: " << health << endl << "*******" << endl;
	}
}

void Pokemon::ReadyBattle(Rival* in_target)
{
	if (state == IN_ARENA && current_arena->IsAbleToFight(pokemon_dollars, stamina) && !current_arena->IsBeaten() && in_target->IsAlive())
	{
		target = in_target;
		state = BATTLE;
	}
	else
		state = IN_ARENA;
}

bool Pokemon::StartBattle()
{
	while (health>0 && target->get_health()>0)
	{
		TakeHit();
		target->TakeHit();
	}
	if (target->get_health() <= 0)
		return true;
	else
		return false;
	//returns true if pokemon wins, false if rival wins
}