#include "Rival.h"
#include "BattleArena.h"
#include "Point2D.h"
#include "GameObject.h"
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

Rival::Rival() :GameObject('R')
{
	name = "Default Rival";
	speed = 5;
	health = 20;
	physical_damage = 5;
	magical_damage = 4;
	defense = 15;
	is_in_arena = false;
	current_arena = NULL;
	cout << "Default rival constructed" << endl;
}

Rival::Rival(string in_name, double in_speed, double hp, double phys_dmg, double magic_dmg, double def, int id, Point2D in_loc) : GameObject(in_loc, id, 'R')
{
	name = in_name;
	speed = in_speed;
	health = hp;
	physical_damage = phys_dmg;
	magical_damage = magic_dmg;
	defense = def;
	is_in_arena = false;
	current_arena = NULL;
	cout << "Rival constructed" << endl;
}

void Rival::TakeHit()
{
	int num = (rand()) % 2;
	if (num == 1)
	{
		double damage = (100 - defense) / 100 * physical_damage;
		health = health - damage;
		cout << name << " : Aaagh, no physical pain no gain!" << endl;
		cout << "Damage: " << damage << endl << "Health: " << health << endl << "*******" << endl;
	}
	else
	{
		double damage = (100 - defense) / 100 * magical_damage;
		health = health - damage;
		cout << name << " : Ouch, I don't believe magic!" << endl;
		cout << "Damage: " << damage << endl << "Health: " << health << endl << "*******" << endl;
	}
}

double Rival::get_phys_dmg()
{
	return physical_damage;
}

double Rival::get_magic_dmg()
{
	return magical_damage;
}

double Rival::get_defense()
{
	return defense;
}

double Rival::get_health()
{
	return health;
}

string Rival::get_name()
{
	return name;
}

bool Rival::Update()
{
	if (state == FAINTED_RIVAL)
		return false;
	else if (health > 0 && state == ALIVE_RIVAL)
		return false;
	else
	{
		state = FAINTED_RIVAL;
		cout << "Rival " << id_num << " is fainted" << endl;
		return true;
	}
}

void Rival::ShowStatus()
{
	cout << name << " Status: ";
	GameObject::ShowStatus();
	if (state == FAINTED_RIVAL)
		cout << " fainted" << endl;
	else
		cout << " alive" << endl;
	cout << "Health: " << health << endl;
	cout << "Physical Damage: " << physical_damage << endl;
	cout << "Magical Damage: " << magical_damage << endl;
	cout << "Defense: " << defense << endl;
}

bool Rival::IsAlive()
{
	if (health > 0)
		return true;
	else
	{
		return false;
		state = FAINTED_RIVAL;
		cout << "Rival " << id_num << " is fainted" << endl;
	}
}

bool Rival::ShouldBeVisible()
{
	return true;
}

void Rival::SetArena(BattleArena* arena)
{
	current_arena = arena;
	arena->AddOneRival();
}
