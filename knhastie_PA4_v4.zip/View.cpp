#include "Point2D.h"
#include "View.h"
#include "GameObject.h"
#include <iostream>
using namespace std;

bool View::GetSubscripts(int& out_x, int& out_y, Point2D location)
{
	//calculates column and row subscripts corresponding to location, assigns them to out_x and out_y
	double x = (location.x - origin.x) / scale;
	double y = (location.x - origin.x) / scale;
	out_x = static_cast<int>(x);
	out_y = static_cast<int>(y);
	//returns true if subscripts are within size of grid being displayed, false otherwise
	if (out_x <= size && out_y <= size)
		return true;
	else
	{
		cout << "An object is outside the display" << endl;
		return false;
	}
}

View::View()
{
	size = 11;
	scale = 2;
	origin.x = 0;
	origin.y = 0;
}

void View::Clear()
{
	for (int row = 0; row < 11; row++)
	{
		for (int column = 0; column < 11; column++)
		{
			grid[row][column][0] = '.';
			grid[row][column][1] = ' ';
		}
	}
}

void View::Plot(GameObject* ptr)
{
	//calls GetSubscripts, if valid calls DrawSelf for object
	int x;
	int y;
	if (GetSubscripts(x, y, ptr->GetLocation()))
		ptr->DrawSelf(grid[11 - x][y - 1]);
	//11-x used instead of x because grid prints rows in reverse, with larger items at top instaed of bottom
	//y-1 used instead of y to account for grid[0][0]
}

void View::Draw()
{
	for (int row = 0; row < 11; row++)
	{
		if (row % 2 == 0)
		{
			cout << 20 - (row * 2);
			if (row * 2 > 10)
				cout << " ";
		}
		else if (row == 10)
			cout << "0 ";
		else
			cout << "  ";
		for (int column = 0; column < 11; column++)
		{
			cout << grid[row][column][0] << grid[row][column][1];
		}
		cout << endl;
	}
	cout << "  0   4   8   12  16  20" << endl;
}
