#include "Building.h"
#include "GameObject.h"
#include "Point2D.h"

Building::Building() :GameObject('B')
{
	pokemon_count = 0;
	cout << "Building default constructed" << endl;
}

Building::Building(char in_code, int in_Id, Point2D in_loc) :GameObject(in_loc, in_Id, in_code)
{
	pokemon_count = 0;
	cout << "Building constructed" << endl;
}

void Building::AddOnePokemon()
{
	pokemon_count++;
}

void Building::RemoveOnePokemon()
{
	pokemon_count--;
}

void Building::ShowStatus()
{
	if (pokemon_count == 1)
		cout << "1 pokemon is in this building" << endl;
	else
		cout << pokemon_count << " pokemon are in this building" << endl;
}

bool Building::ShouldBeVisible()
{
	return true;
}