#include "Point2D.h"
#include <iostream>
#include <cmath>
using namespace std;

Point2D::Point2D()
{
	x = 0.0;
	y = 0.0;
}
//default constructor initializes x and y to 0.0

Point2D::Point2D(double in_x, double in_y)
{
	x = in_x;
	y = in_y;
}
//constructor with two inputs assigns inputs to x and y values

double GetDistanceBetween(Point2D& p1, Point2D& p2)
{
	double x = pow(p2.x - p1.x, 2);
	double y = pow(p2.y - p1.y, 2);
	double out = sqrt(x + y);
	return out;
}

ostream& operator<<(ostream& out, const Point2D& p)
{
	out << "(" << p.x << ", " << p.y << ")";
	return out;
}

Point2D operator+(const Point2D& p1, const Vector2D& v1)
{
	Point2D pout;
	pout.x = p1.x + v1.x;
	pout.y = p1.y + v1.y;
	return pout;
}

Vector2D operator-(const Point2D& p1, const Point2D& p2)
{
	Vector2D vout;
	vout.x = p1.x - p2.x;
	vout.y = p1.y - p2.y;
	return vout;
}