#include <iostream>
using namespace std;

#ifndef VECTOR2D_H
#define VECTOR2D_H

class Vector2D
{
public:
	double x;
	double y;
	//2 length data fields

	Vector2D();
	Vector2D(double in_x, double in_y);
};

Vector2D operator*(const Vector2D& v1, const double d);
Vector2D operator/(const Vector2D& v1, const double d);
ostream& operator<<(ostream& out, const Vector2D& v1);

#endif