#include "Point2D.h"
#include "GameObject.h"

GameObject::GameObject(char in_code)
{
	display_code = in_code;
	id_num = 1;
	state = 0;
	cout << "GameObject constructed" << endl;
}
//initializes GameObject given only object name

GameObject::GameObject(Point2D in_loc, int in_id, char in_code)
{
	display_code = in_code;
	id_num = in_id;
	location = in_loc;
	state = 0;
	cout << "GameObject constructed" << endl;
}
//initializes GameObject given object location, ID and name

Point2D GameObject::GetLocation()
{
	return location;
}
//returns location for object

int GameObject::GetId()
{
	return id_num;
}
//returns ID for this object

char GameObject::GetState()
{
	return state;
}
//returns state for this object

void GameObject::ShowStatus()
{
	cout << display_code << id_num << " located at " << location;
}

void GameObject::DrawSelf(char* ptr)
{
	if (*ptr == '.')
	{
		*ptr = display_code;
		*(ptr + 1) = id_num + 48;
	}
	else
		*ptr = '*';
}