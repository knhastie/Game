#include <iostream>
#include "Vector2D.h"
using namespace std;

Vector2D::Vector2D()
{
	x = 0.0;
	y = 0.0;
}
//default constructor initializes x and y to 0.0

Vector2D::Vector2D(double in_x, double in_y)
{
	x = in_x;
	y = in_y;
}
//constructor with two inputs assigns inputs to x and y values

Vector2D operator*(const Vector2D& v1, const double d)
{
	Vector2D vout;
	vout.x = v1.x * d;
	vout.y = v1.y * d;
	return vout;
};
//returns original vector multiplied by value d

Vector2D operator/(const Vector2D& v1, const double d)
{
	if (d == 0)
		return v1;
	else
	{
		Vector2D vout;
		vout.x = v1.x / d;
		vout.y = v1.y / d;
		return vout;
	}
};
//returns original vector divided by value d unless d=0 (then just returns original vector)

ostream& operator<<(ostream& out, const Vector2D& v1)
{
	out << "<" << v1.x << ", " << v1.y << ">";
	return out;
};
//prints vector size in <x, y> form