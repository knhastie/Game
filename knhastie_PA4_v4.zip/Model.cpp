#include "Point2D.h"
#include "Vector2D.h"
#include "GameObject.h"
#include "PokemonGym.h"
#include "PokemonCenter.h"
#include "BattleArena.h"
#include "Pokemon.h"
#include "Rival.h"
#include "View.h"
#include "Model.h"
#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
using namespace std;



Model::Model()
{
	//sets time to zero
	time = 0;
	//creates and stores initial objects in lists using new
	Point2D p(5, 1);
	Pokemon* P1 = new Pokemon("Pikachu", 2, 30, 6, 2, 40, 1, 'P', p);
	pokemon_ptrs.push_back(P1);
	object_ptrs.push_back(P1);
	p.x = 10;
	p.y = 1;
	Pokemon* P2 = new Pokemon("Bulbasaur", 1, 40, 2, 8, 20, 2, 'P', p);
	pokemon_ptrs.push_back(P2);
	object_ptrs.push_back(P2);
	p.x = 3;
	p.y = 3;
	BattleArena* A1 = new BattleArena(3, 30, 10, 1, p);
	Rival* R1 = new Rival("Voldemort", 5, 40, 7, 1, 12, 1, p);
	R1->SetArena(A1);
	rival_ptrs.push_back(R1);
	object_ptrs.push_back(R1);
	Rival* R2 = new Rival("Smaug", 3, 30, 1, 8, 90, 2, p);
	R2->SetArena(A1);
	rival_ptrs.push_back(R2);
	object_ptrs.push_back(R2);
	Rival* R3 = new Rival("Moriarti", 4, 50, 5, 5, 70, 9, p);
	rival_ptrs.push_back(R3);
	object_ptrs.push_back(R3);
	p.x = 1;
	p.y = 20;
	PokemonCenter* C1 = new PokemonCenter(1, 1, 100, p);
	center_ptrs.push_back(C1);
	object_ptrs.push_back(C1);
	p.x = 10;
	p.y = 20;
	PokemonCenter* C2 = new PokemonCenter(2, 2, 200, p);
	center_ptrs.push_back(C2);
	object_ptrs.push_back(C2);
	p.x = 0;
	p.y = 0;
	PokemonGym* G1 = new PokemonGym(10, 1, 2, 3, 1, p);
	gym_ptrs.push_back(G1);
	object_ptrs.push_back(G1);
	p.x = 5;
	p.y = 5;
	PokemonGym* G2 = new PokemonGym(20, 5, 7.5, 8, 2, p);
	gym_ptrs.push_back(G2);
	object_ptrs.push_back(G2);
	p.x = 3;
	p.y = 3;
	arena_ptrs.push_back(A1);
	object_ptrs.push_back(A1);
	//creates active_ptrs (initially complete object_ptrs list because no objects start the game dead)
	active_ptrs = object_ptrs;
	//prints constructor message
	cout << "Model default constructed" << endl;
}

Model::~Model()
{
	//deletes each pointer by cycling through iterator outputs (pointers TO pointers in list)
	for (list<GameObject*>::iterator it = object_ptrs.begin(); it != object_ptrs.end(); ++it)
		delete (*it);
	//prints destructor message
	cout << "Model destructed" << endl;
}

Pokemon* Model::GetPokemonPointer(int id)
{
	//searches pokemon_ptrs list for Pokemon with given id
	for (list<Pokemon*>::iterator it = pokemon_ptrs.begin(); it != pokemon_ptrs.end(); ++it)
	{
		if ((*it)->GetId() == id)
			//returns ptr for Pokemon if found
			return *it;
	}
	//returns zero if not (only reaches return out statement if no pokemon in array had ID id)
	return NULL;
}

PokemonCenter* Model::GetPokemonCenterPtr(int id)
{
	//searches center_ptrs list for PokemonCenter with given id
	for (list<PokemonCenter*>::iterator it = center_ptrs.begin(); it != center_ptrs.end(); ++it)
	{
		if ((*it)->GetId() == id)
			//returns ptr for PokemonCenter if found
			return *it;
	}
	//returns zero if not (only reaches return out statement if no pokemon in array had ID id)
	return NULL;
}

PokemonGym* Model::GetPokemonGymPtr(int id)
{
	//searches gym_ptrs list for PokemonGym with given id
	for (list<PokemonGym*>::iterator it = gym_ptrs.begin(); it != gym_ptrs.end(); ++it)
	{
		if ((*it)->GetId() == id)
			//returns ptr for PokemonGym if found
			return *it;
	}
	//returns zero if not (only reaches return out statement if no pokemon in array had ID id)
	return NULL;
}

Rival* Model::GetRivalPointer(int id)
{
	//searches rival_ptrs list for Rival with given id
	for (list<Rival*>::iterator it = rival_ptrs.begin(); it != rival_ptrs.end(); ++it)
	{
		if ((*it)->GetId() == id)
			//returns ptr for Rival if found
			return *it;
	}
	//returns zero if not (only reaches return out statement if no pokemon in array had ID id)
	return NULL;
}

BattleArena* Model::GetBattleArenaPtr(int id)
{
	//searches arena_ptrs list for Arena with given id
	for (list<BattleArena*>::iterator it = arena_ptrs.begin(); it != arena_ptrs.end(); ++it)
	{
		if ((*it)->GetId() == id)
			//returns ptr for Arena if found
			return *it;
	}
	//returns zero if not (only reaches return out statement if no pokemon in array had ID id)
	return NULL;
}

bool Model::Update()
{
	//increments time
	time++;
	int anytrue = 0;
	//updates all objects and keeps track of if any object.Update() returns true
	for (list<GameObject*>::iterator it = active_ptrs.begin(); it != active_ptrs.end(); ++it)
	{
		bool thisobj = (*it)->Update();
		if (thisobj)
			anytrue++;
	}
	//if all gyms are beaten, player wins
	int anyunbeaten = 0;
	for (list<PokemonGym*>::iterator it = gym_ptrs.begin(); it != gym_ptrs.end(); ++it)
	{
		if (!((*it)->IsBeaten()))
			anyunbeaten++;
	}
	if (anyunbeaten == 0)
	{
		cout << "GAME OVER: You win! All Pokemon Gyms beaten!" << endl;
		//exit command!
	}
	//if all pokemon are exhausted, player loses
	int anynotexhausted = 0;
	for (list<Pokemon*>::iterator it = pokemon_ptrs.begin(); it != pokemon_ptrs.end(); ++it)
	{
		if ((*it)->GetState() != EXHAUSTED)
			anynotexhausted++;
	}
	if (anynotexhausted == 0)
	{
		cout << "GAME OVER: You lose! All of your Pokemon are tired!" << endl;
		//exit command!
	}
	//if any object.Update() returned true in first object_ptrs loop, returns true
	if (anytrue > 0)
		return true;
	else
		return false;
}

//cannot make until View files are made
void Model::Display(View& view)
{
	view.Clear();
	for (list<GameObject*>::iterator it = active_ptrs.begin(); it != active_ptrs.end(); ++it)
		view.Plot(*it);
	view.Draw();
}

void Model::ShowStatus()
{
	cout << "Time: " << time << endl;
	//loops through all objects using virtual Object.ShowStatus() function (should be overloaded by derived ShowStatus functions)
	for (list<GameObject*>::iterator it = object_ptrs.begin(); it != object_ptrs.end(); ++it)
		(*it)->ShowStatus();
}

void Model::NewCommand(char type, int id, double x_in, double y_in)
{
	//error-check to see if ID_num is taken in this function
	//using rand() to create randomized values for new object characteristics
	Point2D p(x_in, y_in);
	PokemonGym* Gn;
	PokemonCenter* Cn;
	Pokemon* Pn;
	Rival* Rn;
	switch (type)
	{
	case 'g':
		Gn = new PokemonGym((rand() % 25 + 10), (rand() % 3 + 1), (rand() % 3 + 1), (rand() % 5 + 1), id, p);
		gym_ptrs.push_back(Gn);
		object_ptrs.push_back(Gn);
		active_ptrs.push_back(Gn);
		break;
	case 'c':
		Cn = new PokemonCenter(id, (rand() % 5 + 1), (rand() % 150 + 50), p);
		center_ptrs.push_back(Cn);
		object_ptrs.push_back(Cn);
		active_ptrs.push_back(Cn);
		break;
	case 'p':
		Pn = new Pokemon(namesP[rand() % 5], (rand() % 5 + 1), (rand() % 30 + 15), (rand() % 10 + 1), (rand() % 10 + 1), (rand() % 60 + 10), id, 'P', p);
		pokemon_ptrs.push_back(Pn);
		object_ptrs.push_back(Pn);
		active_ptrs.push_back(Pn);
		break;
	case 'r':
		Rn = new Rival(namesR[rand() % 5], (rand() % 5 + 1), (rand() % 30 + 15), (rand() % 10 + 1), (rand() % 10 + 1), (rand() % 60 + 10), id, p);
		rival_ptrs.push_back(Rn);
		object_ptrs.push_back(Rn);
		active_ptrs.push_back(Rn);
		break;
	}
}
