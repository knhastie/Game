#include "Point2D.h"
#include "Model.h"
#include "View.h"
#include "GameCommand.h"
#include "Pokemon.h"
#include "PokemonGym.h"
#include "PokemonCenter.h"
#include "Rival.h"

void DoMoveCommand(Model& model, int pokemon_id, Point2D p1)
{
	//prints error message if model or pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts moving specified pokemon
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		pokemon_ptr->StartMoving(p1);
	}
}

void DoMoveToCenterCommand(Model& model, int pokemon_id, int center_id)
{
	//prints error message if pokemon_id or center_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL || model.GetPokemonCenterPtr(center_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts moving specified pokemon to specified center
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		PokemonCenter* center_ptr = model.GetPokemonCenterPtr(center_id);
		pokemon_ptr->StartMovingToCenter(center_ptr);
	}
}

void DoMoveToGymCommand(Model& model, int pokemon_id, int gym_id)
{
	//prints error message if gym_id or pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL || model.GetPokemonGymPtr(gym_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts moving specified pokemon to specified gym
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		PokemonGym* gym_ptr = model.GetPokemonGymPtr(gym_id);
		pokemon_ptr->StartMovingToGym(gym_ptr);
	}
}

void DoMoveToArenaCommand(Model& model, int pokemon_id, int arena_id)
{
	//prints error message if arena_id or pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL || model.GetBattleArenaPtr(arena_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts moving specified pokemon to specified arena
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		BattleArena* arena_ptr = model.GetBattleArenaPtr(arena_id);
		pokemon_ptr->StartMovingToArena(arena_ptr);
	}
}


void DoStopCommand(Model& model, int pokemon_id)
{
	//prints error message if pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else stops specified pokemon
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		pokemon_ptr->Stop();
	}
}

void DoTrainInGymCommand(Model& model, int pokemon_id, unsigned int training_units)
{
	//prints error message if pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts training specified pokemon
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		pokemon_ptr->StartTraining(training_units);
	}
}

void DoRecoverInCenterCommand(Model& model, int pokemon_id, unsigned int stamina_points)
{
	//prints error message if pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts recovering stamina of specified pokemon
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		pokemon_ptr->StartRecoveringStamina(stamina_points);
	}
}

void DoBattleInArenaCommand(Model& model, int pokemon_id, int rival_id)
{
	//prints error message if pokemon_id is invalid
	if (model.GetPokemonPointer(pokemon_id) == NULL || model.GetRivalPointer(rival_id)==NULL)
		cout << "Error: Please enter a valid command!" << endl;
	//else starts recovering stamina of specified pokemon
	else
	{
		Pokemon* pokemon_ptr = model.GetPokemonPointer(pokemon_id);
		Rival* rival_ptr = model.GetRivalPointer(rival_id);
		pokemon_ptr->ReadyBattle(rival_ptr);
	}
}

void DoCreateNewObjectCommand(Model& model, char type, int id, double x_in, double y_in)
{
	model.NewCommand(type, id, x_in, y_in);
}

void DoGoCommand(Model& model, View& view)
{
	//updates all game objects via Model class update command, then displays current game view
	bool t = model.Update();
	model.ShowStatus();
}

void DoRunCommand(Model& model, View& view)
{
	//repeatedly updates all game objects via Model class update command until a signficant event happens (an object's state changes)
	//model.Update will only return false if NO objects have changed state
	bool t;
	do
	{
		t = model.Update();
	} while (!t);
	model.ShowStatus();
}
