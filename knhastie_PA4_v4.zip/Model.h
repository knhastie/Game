#ifndef MODEL_H
#define MODEL_H

#include "GameObject.h"
#include "PokemonGym.h"
#include "PokemonCenter.h"
#include "Pokemon.h"
#include "Rival.h"
#include "BattleArena.h"
#include "View.h"
#include <list>
using namespace std;

class Model
{
private:
	int time;
	int num_objects;
	int num_pokemon;
	int num_centers;
	int num_gyms;
	int num_rivals;
	int num_arenas;
	list <GameObject*> object_ptrs;
	list <GameObject*> active_ptrs;
	list <Pokemon*> pokemon_ptrs;
	list <PokemonCenter*> center_ptrs;
	list <PokemonGym*> gym_ptrs;
	list <Rival*> rival_ptrs;
	list <BattleArena*> arena_ptrs;
	//creating string arrays for randomization of names of new objects in NewCommand()
	const string namesP[5] = { "Ivysaur","Charmander","Squirtle","Pidgey","Rattata" };
	const string namesR[5] = { "Maleficent","Morgana","Captain Hook","Jafar","Shego" };

public:
	Model();
	~Model();
	Pokemon* GetPokemonPointer(int id);
	PokemonCenter* GetPokemonCenterPtr(int id);
	PokemonGym* GetPokemonGymPtr(int id);
	Rival* GetRivalPointer(int id);
	BattleArena* GetBattleArenaPtr(int id);
	bool Update();
	void Display(View& view);
	void ShowStatus();
	void NewCommand(char type, int id, double x_in, double y_in);
};

#endif