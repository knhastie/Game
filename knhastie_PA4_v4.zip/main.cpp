//implementation file
#include "Point2D.h"
#include "Vector2D.h"
#include "GameObject.h"
#include "Building.h"
#include "PokemonCenter.h"
#include "PokemonGym.h"
#include "Pokemon.h"
#include "Model.h"
#include "GameCommand.h"
#include "View.h"
#include "Input_Handling.h"
#include <iostream>
#include <cmath>
#include <cstring>
#include <ctime>
#include <cstdlib>
using namespace std;

void CommandHandlingFunction(Model& model, View& view, char c);

int main()
{
	cout << "EC327: Introduction to Software Engineering" << endl << "Fall 2019" << endl << "Programming Assignment 4" << endl;
	//optional Pokemon banner here
	View view;
	Model model;
	model.ShowStatus();
	cout<<"Enter command: ";
	char c;
	cin >> c;
	while (c != 'q')
	{
		CommandHandlingFunction(model, view, c);
		model.Display(view);
		cout<<"Enter command: ";
		cin>>c;
	}
	//Once user enters q, while loop ends, program returns 0 and ends.
	return 0;
}

void CommandHandlingFunction(Model& model, View& view, char c)
{
	unsigned int IDp;
	unsigned int IDb;
	double x;
	double y;
	unsigned int unit_amount;
	char type;
	Point2D p;
	try{
	switch (c)
	{
	case 'm':
		cin>>y;
		cin >> x;
		cin >> y;
		p.x = x;
		p.y = y;
		cout << "moving pokemon " << IDp << " to (" << x << ", " << y << ")" << endl;
		DoMoveCommand(model, IDp, p);
		break;
	case 'g':
		cin >> IDp;
		cin >> IDb;
		cout << "moving pokemon " << IDp << " to gym " << IDb << endl;
		DoMoveToGymCommand(model, IDp, IDb);
		break;
	case 'c':
		cin >> IDp;
		cin >> IDb;
		cout << "moving pokemon " << IDp << " to center " << IDb << endl;
		DoMoveToCenterCommand(model, IDp, IDb);
		break;
	case 's':
		cin >> IDp;
		cout << "stopping pokemon " << IDp << endl;
		DoStopCommand(model, IDp);
		break;
	case 'r':
		cin >> IDp;
		cin >> unit_amount;
		cout << "pokemon " << IDp << " recovering " << unit_amount << " stamina points" << endl;
		DoRecoverInCenterCommand(model, IDp, unit_amount);
		break;
	case 't':
		cin >> IDp;
		cin >> unit_amount;
		cout << "pokemon " << IDp << " training " << unit_amount << " training points" << endl;
		DoTrainInGymCommand(model, IDp, unit_amount);
		break;
	case 'b':
		cin >> IDp;
		cin >> IDb;
		cout << "Pokemon " << IDp << " is battling rival " << IDb << endl;
		DoBattleInArenaCommand(model, IDp, IDb);
		break;
	case 'a':
		cin >> IDp;
		cin >> IDb;
		cout << "Pokemon " << IDp << " is moving towards arena " << IDb << endl;
		DoMoveToArenaCommand(model, IDp, IDb);
		break;
	case 'n':
		cin >> type;
		cin >> IDp;
		cin >> x;
		cin >> y;
		cout << "Creating new game object " << type << IDp << " at location (" << x << ", " << y << ")" << endl;
		DoCreateNewObjectCommand(model, type, IDp, x, y);
		break;
	case 'v':
		cout << "Advancing one tick" << endl;
		DoGoCommand(model, view);
		break;
	case 'x':
		cout << "Advancing to next event" << endl;
		DoRunCommand(model, view);
		break;
	}
	}
catch(Invalid_Input& except){
	cout<<"Invalid input - "<<except.msg_ptr<<endl;
}
}
